import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
   providedIn: 'root'
})
export class MyserviceService {
   // private finaldata = [];
   // private apiurl = "http://jsonplaceholder.typicode.com/users";
   // constructor(private http: HttpClient) { }
   // showTodayDate() {
   //    return this.http.get(this.apiurl);
   // }
   constructor() { }
  showTodayDate() { 
     let tdate = new Date(); 
     return tdate; 
  }  
}