import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';
@Component({
  selector: 'app-new-comp',
  templateUrl: './new-comp.component.html',
  styleUrls: ['./new-comp.component.css']
})
export class NewCmpComponent implements OnInit { 
  title = 'hi';
  newcomponent = "Entered in new component created"; 
 
  todaydate;
  constructor(private myservice: MyserviceService) {} 
  ngOnInit() { 
     this.todaydate = this.myservice.showTodayDate();
}
}
